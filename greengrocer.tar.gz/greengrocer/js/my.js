$(document).ready(function()


{
 
    $('.bxslider').bxSlider({
    	mode: 'horizontal',
    	captions: true
  });

});